import { createBrowserRouter } from "react-router";
import { LandingPage } from "./pages/landing";
import { ClarificationPage } from "./pages/clarification";
import { BlueprintPage } from "./pages/blueprint";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LandingPage,
  },
  {
    path: "/clarify",
    Component: ClarificationPage,
  },
  {
    path: "/blueprint",
    Component: BlueprintPage,
  },
]);
