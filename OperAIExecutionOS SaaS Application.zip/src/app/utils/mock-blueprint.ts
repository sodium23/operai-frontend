export interface BlueprintData {
  ideaInterpretation: {
    summary: string;
    coreValue: string;
    targetUser: string;
    keyAssumptions: string[];
  };
  marketReality: {
    marketSize: string;
    competitors: Array<{ name: string; strength: string }>;
    trends: string[];
    risks: Array<{ risk: string; severity: "High" | "Medium" | "Low" }>;
  };
  moat: {
    differentiators: string[];
    barriers: string[];
    sustainability: string;
  };
  confidence: {
    score: number;
    factors: Array<{ factor: string; impact: "positive" | "negative" }>;
  };
  prd: {
    stories: Array<{
      id: string;
      title: string;
      persona: string;
      want: string;
      so: string;
      criteria: string[];
    }>;
  };
  architecture: {
    components: Array<{ name: string; description: string }>;
    dataFlow: string[];
    scaleTriggers: string[];
  };
  security: {
    considerations: string[];
    compliance: string[];
    governance: string[];
  };
  edgeCases: Array<{
    id: string;
    category: string;
    severity: "High" | "Medium" | "Low";
    description: string;
    mitigation: string;
  }>;
  validation: {
    experiments: Array<{ experiment: string; metric: string; timeline: string }>;
    successCriteria: string[];
  };
}

export function generateMockBlueprint(idea: string): BlueprintData {
  return {
    ideaInterpretation: {
      summary: `A platform designed to ${idea.substring(0, 100)}...`,
      coreValue: "Streamlined connection between supply and demand with intelligent matching",
      targetUser: "Early-stage startups and SMBs seeking specialized services",
      keyAssumptions: [
        "Target users face friction in current marketplace solutions",
        "AI-powered matching provides measurable value over manual search",
        "Users are willing to pay for quality and speed",
        "Market is fragmented enough to warrant a new solution",
      ],
    },
    marketReality: {
      marketSize: "$2.4B addressable market, growing 18% YoY",
      competitors: [
        { name: "Upwork", strength: "Massive network, established trust" },
        { name: "Fiverr", strength: "Low-cost, high volume" },
        { name: "Toptal", strength: "Premium positioning, vetted talent" },
      ],
      trends: [
        "Remote work normalization expanding freelance market",
        "AI-assisted workflow becoming table stakes",
        "Vertical-specific platforms gaining traction",
      ],
      risks: [
        { risk: "Network effects favor incumbents", severity: "High" },
        { risk: "Price compression from competition", severity: "Medium" },
        { risk: "Quality control at scale", severity: "High" },
        { risk: "Regulatory changes in gig economy", severity: "Medium" },
      ],
    },
    moat: {
      differentiators: [
        "AI matching based on style and project fit, not just keywords",
        "Vertical focus enables deeper specialization",
        "Quality-first curation vs. volume-based approach",
      ],
      barriers: [
        "Proprietary matching algorithm trained on domain data",
        "Curated network of pre-vetted professionals",
        "Workflow integration reducing switching costs",
      ],
      sustainability:
        "Moat depends on data quality and network density. Initial advantage is replicable by well-funded competitors within 18-24 months without continuous innovation.",
    },
    confidence: {
      score: 67,
      factors: [
        { factor: "Clear problem validated by market research", impact: "positive" },
        { factor: "Strong competitive landscape", impact: "negative" },
        { factor: "Differentiation requires execution excellence", impact: "negative" },
        { factor: "Proven business model in adjacent spaces", impact: "positive" },
        { factor: "Scalable technology foundation", impact: "positive" },
      ],
    },
    prd: {
      stories: [
        {
          id: "US-001",
          title: "Account Creation",
          persona: "Startup Founder",
          want: "create an account with minimal friction",
          so: "I can quickly post my first project",
          criteria: [
            "Email/Google OAuth sign-up available",
            "No credit card required for account creation",
            "Onboarding completes in under 3 minutes",
            "User receives confirmation email within 30 seconds",
          ],
        },
        {
          id: "US-002",
          title: "Project Posting",
          persona: "Product Manager",
          want: "describe my project requirements in natural language",
          so: "the system can match me with relevant talent without manual filtering",
          criteria: [
            "Free-form text input with AI parsing",
            "Suggested categories and tags presented",
            "Budget and timeline fields required",
            "Preview of project listing before publishing",
          ],
        },
        {
          id: "US-003",
          title: "Smart Matching",
          persona: "Freelance Designer",
          want: "receive project recommendations that fit my style",
          so: "I don't waste time on irrelevant opportunities",
          criteria: [
            "Recommendations appear within 24 hours of onboarding",
            "Match score explained with specific factors",
            "Ability to refine preferences based on recommendations",
            "Notification settings configurable",
          ],
        },
        {
          id: "US-004",
          title: "Proposal Submission",
          persona: "Freelancer",
          want: "submit a proposal with portfolio samples",
          so: "clients can evaluate my fit quickly",
          criteria: [
            "Template for structured proposals",
            "Portfolio attachment (up to 10 images)",
            "Estimated timeline and pricing fields",
            "Client receives proposal notification immediately",
          ],
        },
        {
          id: "US-005",
          title: "Hire & Onboard",
          persona: "Startup Founder",
          want: "hire a freelancer and start work in one session",
          so: "I minimize delay between decision and execution",
          criteria: [
            "One-click hiring from proposal",
            "Automatic contract generation",
            "Payment escrow setup during hire flow",
            "Shared workspace created upon hire",
          ],
        },
      ],
    },
    architecture: {
      components: [
        { name: "Web Application", description: "React SPA with SSR for SEO" },
        { name: "API Gateway", description: "REST/GraphQL hybrid with rate limiting" },
        { name: "Matching Engine", description: "ML-based recommendation system" },
        { name: "Search Service", description: "Elasticsearch for full-text search" },
        { name: "Payment Service", description: "Stripe integration with escrow logic" },
        { name: "Notification Service", description: "Email, push, SMS via unified queue" },
        { name: "File Storage", description: "S3 + CloudFront CDN" },
        { name: "Database", description: "PostgreSQL primary, Redis cache" },
      ],
      dataFlow: [
        "User submits project → API validates → Matching engine processes → Candidates notified",
        "Freelancer views project → Engagement tracked → Model updates weights",
        "Proposal submitted → Client notified → Hire triggers payment & contract flow",
      ],
      scaleTriggers: [
        "10k+ daily active users: Implement read replicas",
        "100k+ projects: Partition database by region",
        "1M+ matches/day: Move matching to dedicated cluster",
        "Notification queue > 50k/min: Auto-scale worker pods",
      ],
    },
    security: {
      considerations: [
        "Payment data never stored directly (Stripe tokenization)",
        "User PII encrypted at rest and in transit",
        "Role-based access control for admin functions",
        "Rate limiting on all public endpoints",
        "Input validation and sanitization on all forms",
      ],
      compliance: [
        "GDPR compliance for EU users (data export, deletion)",
        "CCPA compliance for California users",
        "SOC 2 Type II audit recommended before enterprise tier",
      ],
      governance: [
        "Content moderation for project postings and proposals",
        "Dispute resolution workflow for payment conflicts",
        "Identity verification for high-value transactions",
        "Terms of Service enforcement mechanisms",
      ],
    },
    edgeCases: [
      {
        id: "EC-001",
        category: "Payment",
        severity: "High",
        description: "Freelancer completes work but client disputes quality before releasing escrow",
        mitigation:
          "Implement milestone-based payments with clear acceptance criteria. Third-party arbitration for disputes over $1000. Escrow auto-releases after 14 days if no dispute filed.",
      },
      {
        id: "EC-002",
        category: "Matching",
        severity: "Medium",
        description: "New freelancer has no history, leading to zero match scores",
        mitigation:
          "Cold-start problem solved by: (1) Portfolio analysis during onboarding, (2) Manual curation for first 10 freelancers per category, (3) Collaborative filtering from similar users.",
      },
      {
        id: "EC-003",
        category: "Trust & Safety",
        severity: "High",
        description: "Fraudulent user creates multiple accounts to manipulate reviews or spam",
        mitigation:
          "Device fingerprinting, email domain validation, phone verification for transactions, rate limits on account creation per IP, ML-based fraud detection.",
      },
      {
        id: "EC-004",
        category: "Scale",
        severity: "Medium",
        description: "Viral growth causes 10x spike in traffic over 48 hours",
        mitigation:
          "Auto-scaling infrastructure on AWS/GCP. Queue-based async processing for non-critical paths. CDN for static assets. Database read replicas with connection pooling.",
      },
      {
        id: "EC-005",
        category: "User Experience",
        severity: "Low",
        description: "Client posts project in language not supported by matching algorithm",
        mitigation:
          "Auto-translate to English for matching, preserve original for display. Language preference filter for freelancers. Support for top 10 languages by user base.",
      },
      {
        id: "EC-006",
        category: "Legal",
        severity: "High",
        description: "Freelancer claims employee status, creating liability for platform",
        mitigation:
          "Clear independent contractor agreements. No exclusivity requirements. Users set own rates and schedules. Legal review of ToS by employment counsel. Consider platform vs. employer classification per jurisdiction.",
      },
    ],
    validation: {
      experiments: [
        {
          experiment: "Landing page with waitlist",
          metric: "200+ signups in 2 weeks from cold outreach",
          timeline: "Week 1-2",
        },
        {
          experiment: "Concierge MVP: Manual matching for 10 projects",
          metric: "50%+ hire rate, 4+ NPS from clients",
          timeline: "Week 3-6",
        },
        {
          experiment: "Prototype matching algorithm on test dataset",
          metric: "60%+ match accuracy vs. manual curation",
          timeline: "Week 4-8",
        },
        {
          experiment: "Pricing survey with target users",
          metric: "40%+ willing to pay 15% platform fee",
          timeline: "Week 5-6",
        },
      ],
      successCriteria: [
        "Validated demand: 200+ waitlist signups from target audience",
        "Validated solution fit: 50%+ conversion in concierge MVP",
        "Validated differentiation: Users cite matching quality as top reason to use platform",
        "Validated economics: Unit economics show path to 20%+ margin at scale",
      ],
    },
  };
}
