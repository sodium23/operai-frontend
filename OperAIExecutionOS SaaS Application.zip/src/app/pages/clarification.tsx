import { useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Progress } from "../components/ui/progress";

const CLARIFICATION_QUESTIONS = [
  "Who is your primary target user?",
  "What is the main problem you're solving?",
  "How will you acquire your first 100 users?",
  "What's your key differentiator from existing solutions?",
  "What's your initial monetization strategy?",
];

export function ClarificationPage() {
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answer, setAnswer] = useState("");
  const [answers, setAnswers] = useState<string[]>([]);

  const totalQuestions = CLARIFICATION_QUESTIONS.length;
  const progress = ((currentQuestion + 1) / totalQuestions) * 100;

  const handleContinue = () => {
    const newAnswers = [...answers, answer];
    setAnswers(newAnswers);

    if (currentQuestion < totalQuestions - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setAnswer("");
    } else {
      // Store answers and navigate to blueprint
      sessionStorage.setItem("clarificationAnswers", JSON.stringify(newAnswers));
      navigate("/blueprint");
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <header className="border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-xl font-semibold text-gray-900">OperAIExecutionOS</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center px-6 py-16">
        <div className="w-full max-w-2xl">
          {/* Progress Indicator */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">
                Question {currentQuestion + 1} of {totalQuestions}
              </span>
              <span className="text-sm text-gray-500">{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Question */}
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-6">
                {CLARIFICATION_QUESTIONS[currentQuestion]}
              </h2>
              <Input
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                placeholder="Your answer..."
                className="text-base"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === "Enter" && answer.trim()) {
                    handleContinue();
                  }
                }}
              />
            </div>

            <Button
              onClick={handleContinue}
              disabled={!answer.trim()}
              className="w-full h-12 text-base bg-indigo-600 hover:bg-indigo-700 text-white"
            >
              Continue
            </Button>
          </div>

          {/* Back Link */}
          <button
            onClick={() => navigate("/")}
            className="mt-8 text-sm text-gray-600 hover:text-gray-900"
          >
            ← Back to start
          </button>
        </div>
      </main>
    </div>
  );
}
