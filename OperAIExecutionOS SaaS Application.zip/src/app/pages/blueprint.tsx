import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { ScrollArea } from "../components/ui/scroll-area";
import { generateMockBlueprint, BlueprintData } from "../utils/mock-blueprint";
import { IdeaInterpretation } from "../components/blueprint/idea-interpretation";
import { MarketReality } from "../components/blueprint/market-reality";
import { MoatAnalysis } from "../components/blueprint/moat-analysis";
import { ConfidenceScore } from "../components/blueprint/confidence-score";
import { ProductBlueprint } from "../components/blueprint/product-blueprint";
import { PRDSection } from "../components/blueprint/prd-section";
import { ArchitectureSection } from "../components/blueprint/architecture-section";
import { SecuritySection } from "../components/blueprint/security-section";
import { EdgeCasesSection } from "../components/blueprint/edge-cases-section";
import { ValidationSection } from "../components/blueprint/validation-section";
import { IdeaChat } from "../components/idea-chat";
import { ArrowLeft } from "lucide-react";

type Section =
  | "idea"
  | "market"
  | "moat"
  | "confidence"
  | "blueprint"
  | "prd"
  | "architecture"
  | "security"
  | "edgecases"
  | "validation";

export function BlueprintPage() {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<Section>("idea");
  const [blueprintData, setBlueprintData] = useState<BlueprintData | null>(null);
  const [currentIdeaId, setCurrentIdeaId] = useState<string>("");

  useEffect(() => {
    const idea = sessionStorage.getItem("productIdea");
    const ideaId = sessionStorage.getItem("currentIdeaId");
    if (!idea) {
      navigate("/");
      return;
    }
    setBlueprintData(generateMockBlueprint(idea));
    setCurrentIdeaId(ideaId || Date.now().toString());
  }, [navigate]);

  if (!blueprintData) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <p className="text-gray-500">Loading blueprint...</p>
      </div>
    );
  }

  const sections = [
    { id: "idea" as Section, label: "Idea Interpretation" },
    { id: "market" as Section, label: "Market Reality" },
    { id: "moat" as Section, label: "Moat Analysis" },
    { id: "confidence" as Section, label: "Confidence Score" },
    { id: "blueprint" as Section, label: "Product Blueprint" },
    { id: "prd" as Section, label: "PRD" },
    { id: "architecture" as Section, label: "Architecture" },
    { id: "security" as Section, label: "Security & Governance" },
    { id: "edgecases" as Section, label: "Critical Edge Cases" },
    { id: "validation" as Section, label: "Validation Plan" },
  ];

  return (
    <div className="h-screen bg-white flex flex-col overflow-hidden">
      {/* Header */}
      <header className="border-b border-gray-200 px-6 py-4 flex-shrink-0">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-semibold text-gray-900">OperAIExecutionOS</h1>
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-4 h-4" />
            New Blueprint
          </button>
        </div>
      </header>

      {/* Main Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar */}
        <aside className="w-64 border-r border-gray-200 flex-shrink-0">
          <ScrollArea className="h-full">
            <nav className="p-4 space-y-1">
              {sections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full text-left px-3 py-2 text-sm rounded-md transition-colors ${
                    activeSection === section.id
                      ? "bg-indigo-50 text-indigo-700 font-medium"
                      : "text-gray-700 hover:bg-gray-50"
                  }`}
                >
                  {section.label}
                </button>
              ))}
            </nav>
          </ScrollArea>
        </aside>

        {/* Right Content Area */}
        <main className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="p-8 max-w-4xl">
              {activeSection === "idea" && (
                <IdeaInterpretation data={blueprintData.ideaInterpretation} />
              )}
              {activeSection === "market" && (
                <MarketReality data={blueprintData.marketReality} />
              )}
              {activeSection === "moat" && (
                <MoatAnalysis data={blueprintData.moat} />
              )}
              {activeSection === "confidence" && (
                <ConfidenceScore data={blueprintData.confidence} />
              )}
              {activeSection === "blueprint" && (
                <ProductBlueprint />
              )}
              {activeSection === "prd" && (
                <PRDSection data={blueprintData.prd} />
              )}
              {activeSection === "architecture" && (
                <ArchitectureSection data={blueprintData.architecture} />
              )}
              {activeSection === "security" && (
                <SecuritySection data={blueprintData.security} />
              )}
              {activeSection === "edgecases" && (
                <EdgeCasesSection data={blueprintData.edgeCases} />
              )}
              {activeSection === "validation" && (
                <ValidationSection data={blueprintData.validation} />
              )}
            </div>
          </ScrollArea>
        </main>
      </div>

      {/* AI Chat Assistant */}
      {currentIdeaId && <IdeaChat ideaId={currentIdeaId} />}
    </div>
  );
}